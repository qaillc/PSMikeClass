﻿# Implicitly create a variable and assign a value
$x = 5

# Implicitly create an array
$a = 1,2,3,4,5,6

# Display both
$x
$a

# Demonstrate poor-practice variable names
${variable names like this are hard to work with} = 'bad'
${variable names like this are hard to work with}

# work with individual array items
$a[0]
$a[-1]
$a[1]
