﻿#Requires –version 3.0
#Requires –modules ActiveDirectory,NetAdapter

# These must go at the TOP of the file before any code
# or comment-based help
# Try running this.