﻿Get-WmiObject -Class Win32_BIOS -ComputerName Alpha,NoName,Bravo -EA SilentlyContinue

Get-WmiObject -Class Win32_BIOS -ComputerName Alpha,NoName,Bravo -EA Stop

